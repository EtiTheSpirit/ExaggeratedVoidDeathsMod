# Exaggerated Void Deaths

You know what looks cool? That gorgeous, sharp implosion effect caused by the Lost Seer's Lenses. I am so fond of the VFX that I even added it to my Void player character mods when the player's black hole kills stuff.

People really liked that, thought it looked kickass to see that slew of damage numbers violently shoot out from the site of the implosion.

So here's a mod that does that on *every* type of void instakill. Fear not, your ears will not implode with the 50 lemurians you just deleted. This variation of the VFX is silent, allowing the natural implosion sound of Void enemies to do the work of providing auditory feedback to you.

This does not affect the Lost Seer's Lenses in any way.

# Interested in my mods?
I have a Discord server dedicated to my mods for all the games that I make mods for! You can join it [here](https://discord.gg/YGJ7a44UEE).